// let a = +prompt('son yoz')
// let b = +prompt('son yoz')
// let c = prompt('+ / * **')

// if(c === "+") {
//     console.log(a + b)
// } else if (c === "/") {
//   console.log(a / b)
// }
// else if (c === "*") {
//   console.log(a * b)  
// }
// else if (c === "-") {
//   console.log(a - b)  
// }
// else if (c === "**") {
//   console.log(a ** b)  
// }
// else {
//     console.log("такое оператор не существует")
// }


let random = Math.ceil(Math)