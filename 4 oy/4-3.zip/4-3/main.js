// let speed = +prompt('tezlikni yoz')
// let ism = prompt('ism yoz')
// let moshina = ('moshina nomerini yoz')
// let kocha = prompt('kocha nomi')
// let modda = prompt('modda')
// let model = prompt('moshina rusumi')

// let date = new Date()

// let skidka = 2


// if (speed > 65 && 80 > speed) {
//     console.log("===========================")
//     console.log("Qoyda Buzarning Ismi:" + ism)
//     console.log("mashina Raqami:" + moshina)
//     console.log("Kochaning Nomi:" + kocha)
//     console.log("Modda" + modda)
//     console.log("Model" + model)
//     console.log("Jarima Summasi:" + clbdgjbjbhiguhuhgurghruighrgu)
// }












let ism = prompt('Ism Yoz')
let kasb = prompt('kasb yoz')
let random = Math.ceil(Math.random)

if(kasb === "yurist") {
    console.log("ism:" + ism)
    console.log("kasb:" + kasb)
    console.log("oylik: 800$")
}
if(kasb === "logistika") {
    console.log("ism:" + ism)
    console.log("kasb:" + kasb)
    console.log("oylik: 1200$")
}
if(kasb === "trading") {
    console.log("ism:" + ism)
    console.log("kasb:" + kasb)
    console.log("oylik: 10$ / 10000$")
}
if(kasb === "developer") {
    console.log("ism:" + ism)
    console.log("kasb:" + kasb)
    console.log("oylik: 1447$ /26000$")
}
if(kasb === "futbalist") {
    console.log("ism:" + ism)
    console.log("kasb:" + kasb)
    console.log("oylik: 8000$")
}
if(kasb === "buhgalter") {
    console.log("ism:" + ism)
    console.log("kasb:" + kasb)
    console.log("oylik: 600$ / 2000$")
}
if(kasb === "prorab") {
    console.log("ism:" + ism)
    console.log("kasb:" + kasb)
    console.log("oylik: 1200$")
}
if(kasb === "admin") {
    console.log("ism:" + ism)
    console.log("kasb:" + kasb)
    console.log("oylik: 600$")
}
if(kasb === "ustoz") {
    console.log("ism:" + ism)
    console.log("kasb:" + kasb)
    console.log("oylik: 400$")
}
if(kasb === "manager") {
    console.log("ism:" + ism)
    console.log("kasb:" + kasb)
    console.log("oylik: 1000$")
}