let money = +prompt("Pul Kirit")
let product = +prompt(
    " \n 1) Coca Cola 6000sum \n 2)Fanta 6000sum \n 3)Lays 16000sum \n 4)Limonad 5000sum \n 5)Mars Grenki 8000sum \n 6)Zaratka 25000sum \n 7)Naushnik  90000sum \n 8)Lava Lava \n 9)Flash 9000sum \n 10)18+ 10000sum"
);

let date = new Date ()
let time = `${date.getHours()}:${date.getMinutes()}:${date.getSeconds}`

if (money >= 6000 && product === 1) {
    console.log("================")
    console.log("##### QR CODE #######")
    console.log(`Product Name: Coca Cola`)
    console.log("Price: 6000sum")
    console.log("Спасибо за покупку")
    console.log("Время Покупки:" + time)
    console.log("=================")
} else if (money >= 5000 && product === 2) {
    console.log("==================")
    console.log("####### QR CODE #######")
    console.log(`Product Name: Fanta`)
    console.log("Price: 6000sum")
    console.log("Спасибо за покупку")
    console.log("Время Покупки:" + time)
    console.log("=================")
}
if (money >= 6000 && product === 3) {
    console.log("================")
    console.log("##### QR CODE #######")
    console.log(`Product Name: Coca Cola`)
    console.log("Price: 6000sum")
    console.log("Спасибо за покупку")
    console.log("Время Покупки:" + time)
    console.log("=================")
} else if (money >= 5000 && product === 4) {
    console.log("==================")
    console.log("####### QR CODE #######")
    console.log(`Product Name: Lays`)
    console.log("Price: 16000sum")
    console.log("Спасибо за покупку")
    console.log("Время Покупки:" + time)
    console.log("=================")
}if (money >= 6000 && product === 5) {
    console.log("================")
    console.log("##### QR CODE #######")
    console.log(`Product Name: Coca Cola`)
    console.log("Price: 6000sum")
    console.log("Спасибо за покупку")
    console.log("Время Покупки:" + time)
    console.log("=================")
} else if (money >= 5000 && product === 6) {
    console.log("==================")
    console.log("####### QR CODE #######")
    console.log(`Product Name: Lays`)
    console.log("Price: 16000sum")
    console.log("Спасибо за покупку")
    console.log("Время Покупки:" + time)
    console.log("=================")
}
if (money >= 6000 && product === 7) {
    console.log("================")
    console.log("##### QR CODE #######")
    console.log(`Product Name: Coca Cola`)
    console.log("Price: 6000sum")
    console.log("Спасибо за покупку")
    console.log("Время Покупки:" + time)
    console.log("=================")
} else if (money >= 5000 && product === 8) {
    console.log("==================")
    console.log("####### QR CODE #######")
    console.log(`Product Name: Lays`)
    console.log("Price: 16000sum")
    console.log("Спасибо за покупку")
    console.log("Время Покупки:" + time)
    console.log("=================")
}
if (money >= 6000 && product === 9) {
    console.log("================")
    console.log("##### QR CODE #######")
    console.log(`Product Name: Coca Cola`)
    console.log("Price: 6000sum")
    console.log("Спасибо за покупку")
    console.log("Время Покупки:" + time)
    console.log("=================")
} else if (money >= 5000 && product === 10) {
    console.log("==================")
    console.log("####### QR CODE #######")
    console.log(`Product Name: Lays`)
    console.log("Price: 16000sum")
    console.log("Спасибо за покупку")
    console.log("Время Покупки:" + time)
    console.log("=================")
}