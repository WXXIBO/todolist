let list = document.querySelector('#list')
let input = document.querySelector('input')
let button = document.querySelector('button')

button.addEventListener('click', (event) => {
    event.preventDefault()

    let div = document.createElement('div')

    div.classList.add('flex', 'items-center', 'justify-between', 'text-sm', 'shadow-inner', 'shadow-amder-100', 'px-5', )
})