// let book = {
//     avtor: "Sunnat-Stilla",
//     ism: "Dasturchi",
//     yil: "1777-2024",
//     pages: 2,
//     introduction: {
//         tom1: "Pepsi_Sotib_Oldim",
//         tom2: "A4 Fanati",
        
//     }
// }

// console.log(book.introduction.tom1)   



// let rezume = {
//     ism: "Ibrokhim",
//     surname: "Juraev",
//     age: "14",
//     location: "Mars It School",
//     phonenum: "+998(93)102-22-99",
//     email: "j.ibrokhim003@gmail.com",
// }

// console.log(rezume)

// rezume.height = "156 sm"
// rezume.weight = "57 kg"
// rezume.color = "browne"
// rezume.eyecolor = "black"








let obj1 = {
    a:1 , 
    b:2 , 
    c:3 , 
}

let obj2 = {
    
}

